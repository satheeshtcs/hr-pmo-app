# RestAPINodeMySQL
A sample application for creating Rest API  with Node.js and MySQL
